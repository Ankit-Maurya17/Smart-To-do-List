import { useState, useEffect, useRef } from 'react';
import { FiPlus, FiTrash2, FiCheck, FiSun, FiMoon, FiEdit2, FiSave, FiX } from 'react-icons/fi';

// Import empty state image
const emptyStateImg = '/images/empty-tasks.svg';

function App() {
  const [todos, setTodos] = useState(() => {
    const saved = localStorage.getItem('todos');
    return saved ? JSON.parse(saved) : [];
  });
  const [input, setInput] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');
  const [filter, setFilter] = useState('all');
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('darkMode') === 'true' || false;
  });

  // Apply dark mode class to HTML element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', darkMode);
  }, [darkMode]);

  // Save todos to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = (e) => {
    e.preventDefault();
    const trimmedInput = input.trim();
    if (!trimmedInput) return;

    const newTodo = {
      id: Date.now(),
      text: trimmedInput,
      completed: false,
    };

    setTodos([...todos, newTodo]);
    setInput('');
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const toggleComplete = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const startEditing = (id, text) => {
    setEditingId(id);
    setEditText(text);
  };

  const saveEdit = (id) => {
    const trimmedText = editText.trim();
    if (trimmedText) {
      setTodos(todos.map(todo =>
        todo.id === id ? { ...todo, text: trimmedText } : todo
      ));
    }
    setEditingId(null);
  };

  const clearCompleted = () => {
    setTodos(todos.filter(todo => !todo.completed));
  };

  const filteredTodos = todos.filter(todo => {
    if (filter === 'active') return !todo.completed;
    if (filter === 'completed') return todo.completed;
    return true;
  });

  const activeTodosCount = todos.filter(todo => !todo.completed).length;
  const hasCompletedTodos = todos.some(todo => todo.completed);

  return (
    <div className={`min-h-screen transition-colors duration-500 ${darkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-10 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white">
              <FiCheck size={24} />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              TaskMaster Pro
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-xl bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-all duration-300 text-gray-700 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400"
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {darkMode ? <FiSun size={20} /> : <FiMoon size={20} />}
            </button>
            <div className="hidden sm:block h-8 w-px bg-gray-200 dark:bg-gray-700"></div>
            <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
              {todos.length} {todos.length === 1 ? 'task' : 'tasks'}
            </div>
          </div>
        </div>

        <form onSubmit={addTodo} className="relative mb-8 group">
          <div className="relative transition-all duration-300 hover:scale-[1.01] hover:shadow-lg">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="What's on your mind today?"
              className="w-full p-5 pl-6 pr-14 text-lg bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm"
            />
            {input && (
              <button
                type="button"
                onClick={() => setInput('')}
                className="absolute right-12 top-1/2 transform -translate-y-1/2 p-1.5 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200"
                aria-label="Clear input"
              >
                <FiX size={20} />
              </button>
            )}
            <button
              type="submit"
              disabled={!input.trim()}
              className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-2.5 rounded-xl shadow-sm ${
                input.trim()
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white shadow-blue-200 dark:shadow-blue-900/50'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
              } transition-all duration-300 flex items-center justify-center`}
              aria-label="Add task"
            >
              <FiPlus size={22} className="transform group-hover:rotate-90 transition-transform duration-300" />
            </button>
          </div>
        </form>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden transition-all duration-300 hover:shadow-2xl">
          {filteredTodos.length === 0 ? (
            <div className="p-8 text-center">
              <div className="max-w-xs mx-auto mb-6">
                <img 
                  src={emptyStateImg} 
                  alt="No tasks" 
                  className="w-full h-auto opacity-80 dark:opacity-60"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.style.display = 'none';
                    e.target.nextElementSibling.style.display = 'block';
                  }}
                />
                <div className="hidden text-6xl mb-4">📝</div>
              </div>
              <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-300 mb-2">
                {filter === 'all'
                  ? 'Your task list is empty!'
                  : filter === 'active'
                  ? 'No active tasks'
                  : 'No completed tasks'}
              </h3>
              <p className="text-gray-500 dark:text-gray-400">
                {filter === 'all'
                  ? 'Start by adding a new task above.'
                  : filter === 'active'
                  ? 'You\'ve completed all your tasks. Great job! 🎉'
                  : 'Complete some tasks to see them here.'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100 dark:divide-gray-700">
              {filteredTodos.map((todo) => (
                <div
                  key={todo.id}
                  className={`group flex items-center justify-between p-5 transition-all duration-300 ${
                    todo.completed 
                      ? 'opacity-80 bg-gray-50 dark:bg-gray-800/50' 
                      : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-750/80'
                  } border-b border-gray-100 dark:border-gray-700 last:border-0`}
                >
                  <div className="flex items-center flex-1 min-w-0">
                    <button
                      onClick={() => toggleComplete(todo.id)}
                      className={`flex-shrink-0 w-6 h-6 rounded-lg flex items-center justify-center mr-4 transition-all ${
                        todo.completed
                          ? 'bg-gradient-to-br from-green-500 to-emerald-500 text-white shadow-inner'
                          : 'border-2 border-gray-300 dark:border-gray-600 hover:border-blue-500 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600'
                      }`}
                      aria-label={todo.completed ? 'Mark as incomplete' : 'Mark as complete'}
                    >
                      {todo.completed && <FiCheck size={16} className="text-white" />}
                    </button>
                    
                    {editingId === todo.id ? (
                      <div className="flex-1 flex items-center">
                        <input
                          type="text"
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onBlur={() => saveEdit(todo.id)}
                          onKeyDown={(e) => e.key === 'Enter' && saveEdit(todo.id)}
                          className="flex-1 bg-transparent border-b-2 border-blue-500 focus:outline-none text-gray-800 dark:text-gray-200 py-1 px-2"
                          autoFocus
                        />
                        <button
                          onClick={() => saveEdit(todo.id)}
                          className="ml-2 p-1.5 text-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                          aria-label="Save changes"
                        >
                          <FiSave size={18} />
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-1.5 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                          aria-label="Cancel editing"
                        >
                          <FiX size={18} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex-1 min-w-0">
                        <span
                          className={`block text-gray-800 dark:text-gray-200 text-lg truncate ${
                            todo.completed
                              ? 'line-through text-gray-500 dark:text-gray-500'
                              : ''
                          }`}
                          onDoubleClick={() => startEditing(todo.id, todo.text)}
                        >
                          {todo.text}
                        </span>
                        <div className="text-xs text-gray-400 mt-1">
                          {new Date(todo.id).toLocaleString()}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 ml-3">
                    {editingId !== todo.id && (
                      <button
                        onClick={() => startEditing(todo.id, todo.text)}
                        className="p-1.5 text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors mr-1"
                        aria-label="Edit task"
                      >
                        <FiEdit2 size={18} />
                      </button>
                    )}
                    <button
                      onClick={() => deleteTodo(todo.id)}
                      className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                      aria-label="Delete task"
                    >
                      <FiTrash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="p-4 text-sm text-gray-500 dark:text-gray-400 border-t border-gray-100 dark:border-gray-700 flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="text-sm text-gray-500 dark:text-gray-400">
              {activeTodosCount} {activeTodosCount === 1 ? 'task' : 'tasks'} left
            </div>
            
            <div className="flex items-center bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
              {['all', 'active', 'completed'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                    filter === f
                      ? 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
                  }`}
                >
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>

            {hasCompletedTodos > 0 && (
              <button
                onClick={clearCompleted}
                className="text-sm text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors flex items-center gap-1.5 group"
              >
                <span>Clear completed</span>
                <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-500 dark:text-red-400 text-xs font-medium group-hover:bg-red-200 dark:group-hover:bg-red-800/50 transition-colors">
                  {todos.filter(todo => todo.completed).length}
                </span>
              </button>
            )}
          </div>
        </div>

        <footer className="mt-12 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">
            Double-click to edit a task • Drag to reorder
          </p>
          <div className="flex items-center justify-center gap-4 mt-3">
            <span className="text-xs text-gray-400 dark:text-gray-500">
              {darkMode ? '🌙 Dark' : '☀️ Light'} mode • {new Date().getFullYear()}
            </span>
            <span className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600"></span>
            <span className="text-xs text-gray-400 dark:text-gray-500">
              Developed with ❤️ by Ankit Maurya
            </span>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
